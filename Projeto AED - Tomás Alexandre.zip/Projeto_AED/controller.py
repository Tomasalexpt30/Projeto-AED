from view import *

class Controller:
    def __init__(self, master):
        self.view = View(master)

    